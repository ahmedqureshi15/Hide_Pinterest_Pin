<?php
/*
Plugin Name: Disable-Pins
Description: Disable Pinterest Pins From Images
Author: Muahammad Ahmed Qureshi
Version: 0.1
*/
// Declaring global variable 
global $custom_media_style ;
//function to add custom media field
function custom_media_add_media_custom_field( $form_fields, $post ) {
    $field_value = get_post_meta( $post->ID, 'custom_media_style', true );

    $form_fields['custom_media_style'] = array(
        'value' => $field_value ? $field_value : '',
        'label' => __( 'Want Diable Pin ?' ),
		'helps' => __( 'If you want to disable pins on images, Simply type true! e.g true ' ),
        'input'  => 'text'
    );

	return $form_fields;
	
}
add_filter( 'attachment_fields_to_edit', 'custom_media_add_media_custom_field', null, 2 );

//save your custom media field
function custom_media_save_attachment( $attachment_id ) {
	global  $custom_media_style;
    if ( isset( $_REQUEST['attachments'][ $attachment_id ]['custom_media_style'] ) ) {
     $custom_media_style = $_REQUEST['attachments'][ $attachment_id ]['custom_media_style'];
		update_post_meta( $attachment_id, 'custom_media_style', $custom_media_style );

    }
}
add_action( 'edit_attachment', 'custom_media_save_attachment' );

function modify_post_thumbnail_html($html,$post_id ,$post_thumbnail_id, $size, $attr) {
	global  $custom_media_style;
	global $post;
	
	$post_id = get_post_thumbnail_id();
    $custom_media_style = get_post_meta( $post_id, 'custom_media_style', true );
	echo "custom_media_style->".$custom_media_style;
	if($custom_media_style=="true"){
	$src = wp_get_attachment_image_src($post_id, $size);
	$alt = get_the_title($post_id);
   $html = '<img src="' . $src[0] . '" alt="' . $alt . '" data-pin-nopin="true" />';
   return $html;
}
else 
{
	$src = wp_get_attachment_image_src($post_id, $size);
	$alt = get_the_title($post_id);
   $html = '<img src="' . $src[0] . '" alt="' . $alt . '/>';
   return $html;
}
}
add_filter('post_thumbnail_html', 'modify_post_thumbnail_html', 99, 5);
?>